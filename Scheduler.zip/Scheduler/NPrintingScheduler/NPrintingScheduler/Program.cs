﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Configuration;
using System.Net.Mail;
using System.IO;
using NPrintingScheduler.App_Code;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;

namespace NPrintingScheduler
{
    static class Program
    {
        public static string taskStoragePath = ConfigurationManager.AppSettings["TaskFolderPath"];
        public static string NPrintingTaskCall = ConfigurationManager.AppSettings["NPrintingTaskCall"];
        static void Main(string[] args)
        {
            string taskName = string.Empty;
            string fileName = string.Empty;
            string archiveFilePath = string.Empty;
            try
            {
                try
                {
                    if (!Directory.Exists(taskStoragePath))
                    {
                        Directory.CreateDirectory(taskStoragePath);
                    }
                }
                catch (Exception ex)
                {
                    LoggerHelper.ExcpLogger("NPrintingScheduler", "MainMethodStorageDirectory", ex);
                }
                try
                {
                    var directoryCollection = Directory.GetDirectories(taskStoragePath);
                    foreach (var folder in directoryCollection)
                    {
                        taskName = Path.GetFileName(folder);
                        string archivePath = taskStoragePath + "\\" + taskName + "\\Archive\\" + DateTime.Now.ToString("dd-MM-yyyy");
                        string processPath = taskStoragePath + "\\" + taskName + "\\Processing";
                        try
                        {
                            if (!Directory.Exists(processPath))
                            {
                                Directory.CreateDirectory(processPath);
                            }
                            if (!Directory.Exists(archivePath))
                            {
                                Directory.CreateDirectory(archivePath);
                            }
                        }
                        catch (Exception ex)
                        {
                            LoggerHelper.ExcpLogger("NPrintingScheduler", "MainMethodProcessArchivePathCheck", ex);

                        }

                        try
                        {
                            archiveFilePath = archivePath + "\\" + DateTime.Now.ToString("yyyyMMdd_hhmmss");
                            string[] files = Directory.GetFiles(processPath);
                            int filesCount = Directory.GetFiles(processPath).Count();
                            if (filesCount >= 1)
                            {
                                Directory.Move(processPath, archiveFilePath);
                            }
                        }
                        catch (Exception ex)
                        {
                            LoggerHelper.ExcpLogger("NPrintingScheduler", "MainMethodProcessFileAccess", ex);
                        }

                    }
                }
                catch (Exception ex)
                {
                    LoggerHelper.ExcpLogger("NPrintingScheduler", "MainMethodDirectoryCollectionCheck", ex);
                }
                GetListOfReports();
            }
            catch(Exception ex)
            {
                LoggerHelper.ExcpLogger("NPrintingScheduler", "MainMethod", ex);

            }
        }

        /// <summary> 
        /// Get the report list from database and pass the report ID to second exe.
        /// </summary>
        static void GetListOfReports()
        {
            DataTable reportCollection = null;
            string reportID = string.Empty;
            try
            {
                reportCollection = new DataTable();
                reportCollection = GetReportDetails();
                if (reportCollection != null && reportCollection.Rows.Count > 0)
                {
                    //Get distinct report id's
                    var dtUniquereportList = reportCollection.AsEnumerable()
                    .Select(row => new
                    {
                        ReportID = row.Field<int>("ReportID"),
                    })
                    .Distinct();

                    if(dtUniquereportList!=null && dtUniquereportList.Count()>=0 )
                    {
                        foreach (var reportList in dtUniquereportList.ToList())
                        {
                            reportID = reportList.ReportID.ToString();
                            Process myProcess = new Process();
                            try
                            {
                                myProcess.StartInfo.UseShellExecute = false;
                                myProcess.StartInfo.FileName = NPrintingTaskCall;
                                myProcess.StartInfo.CreateNoWindow = true;
                                myProcess.StartInfo.Arguments = reportID;
                                myProcess.Start();

                            }
                            catch (Exception ex)
                            {
                                LoggerHelper.ExcpLogger("NPrintingScheduler", "GetListOfReports", ex);
                            }
                        }
                    }
                    
                }
            }
            catch (Exception ex)
            {
                LoggerHelper.ExcpLogger("NPrintingScheduler", "GetListOfReports", ex);
            }
        }

        /// <summary> 
        /// Get Task execution details from database.
        /// </summary>
        static DataTable GetReportDetails()
        {
            DataTable getReportDetails = null;

            try
            {
                string taskQuery = DbRepository.GetReportDetails();
                getReportDetails = new DataTable();

                getReportDetails = SQLHelper.ExecuteAdapterWithoutParameter(taskQuery, CommandType.StoredProcedure);

                return getReportDetails;

            }
            catch (Exception ex)
            {
                LoggerHelper.ExcpLogger("NPrintingScheduler", "GetReportDetails", ex);
                return null;
            }
        }

    }
}

