﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Configuration;
using System.Net.Mail;
using System.IO;
using NPrintingTaskCall.App_Code;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;
using System.IO.Compression;

namespace NPrintingTaskCall
{
    static class Program
    {
        public static string taskStoragePath = ConfigurationManager.AppSettings["TaskFolderPath"];
        public static string reportWaitTime = ConfigurationManager.AppSettings["ReportWaitTime"];
        public static string timeDelay = ConfigurationManager.AppSettings["TaskDelay"];
        public static string rptID = string.Empty;
        public static List<string> taskAndReports = new List<string>();

        static void Main(string[] args)
        {
            try
            {
                bool isTaskSchedule = false;
                try
                {
                    rptID = args[0];
                    isTaskSchedule = ExecuteNprintingTask();
                }
                catch (Exception ex)
                {
                    LoggerHelper.ExcpLogger("NPrintingTaskCall", "MainMethodStart", ex);
                }
                if (isTaskSchedule)
                {

                    GetAndSaveAttachment();
                }
            }
            catch (Exception ex)
            {
                LoggerHelper.ExcpLogger("NPrintingTaskCall", "MainMethod", ex);
            }
        }


        /// <summary> 
        /// Set autentication in Nprinting and Get the Task details from database.
        /// </summary>
        static bool ExecuteNprintingTask()
        {
            DataTable taskExecutionDetails = null;
            bool isTaskSchedule = false;
            try
            {
                taskExecutionDetails = new DataTable();
                taskExecutionDetails = GetTaskExecutionDetails();
                if (taskExecutionDetails != null && taskExecutionDetails.Rows.Count > 0)
                {
                    isTaskSchedule = true;


                    foreach (DataRow dr in taskExecutionDetails.Rows)
                    {
                        string taskID = dr["NprintingTaskID"].ToString();
                        string ReportID = dr["ReportID"].ToString();

                        if (ReportID == rptID)
                        {
                            taskAndReports.Add(dr["TaskName"].ToString());
                            NprintingReqResRepository.TasksExecution(taskID);
                            for (int i = 0; i <= (Convert.ToInt32(reportWaitTime) * 6); i++)
                            {
                                if (Directory.Exists(taskStoragePath + "\\" + dr["TaskName"].ToString() + "\\" + "Processing"))
                                {
                                    if (Directory.GetFiles(taskStoragePath + "\\" + dr["TaskName"].ToString() + "\\" + "Processing").Count() > 0)
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        System.Threading.Thread.Sleep(Convert.ToInt32(timeDelay));
                                    }
                                }
                                else
                                {
                                    LoggerHelper.ExcpLogger("NPrintingTaskCall", "ExecuteNprintingTask-Folder does not exists", new Exception("Folder does not exists- " + taskStoragePath + "\\" + dr["TaskName"].ToString() + "\\" + "Processing"));
                                    System.Threading.Thread.Sleep(Convert.ToInt32(timeDelay));
                                }
                            }
                        }
                    }
                }
                return isTaskSchedule;
            }
            catch (Exception ex)
            {
                LoggerHelper.ExcpLogger("NPrintingTaskCall", "ExecuteNprintingTask", ex);
                return isTaskSchedule;
            }
        }

        /// <summary> 
        /// Get attachment details and save attachments in local(Base directory).
        /// </summary>
        static void GetAndSaveAttachment()
        {
            try
            {
                string TaskName = string.Empty;
                string fileName = string.Empty;
                string fileExtension = string.Empty;
                foreach (var folder in taskAndReports)
                {
                    TaskName = folder;
                    try
                    {
                        if (Directory.Exists(taskStoragePath + TaskName + "\\Processing"))
                        {
                            string[] files = Directory.GetFiles(taskStoragePath + TaskName + "\\Processing");
                            foreach (string file in files)
                            {
                                fileExtension = Path.GetExtension(file);
                                if (fileExtension == ".zip")
                                {
                                    ZipFile.ExtractToDirectory(file, taskStoragePath + TaskName + "\\Processing");
                                    File.Delete(file);
                                }
                            }
                        }
                        else
                            LoggerHelper.ExcpLogger("NPrintingTaskCall", "GetAndSaveAttachment", new Exception("Folder does not exists- " + taskStoragePath + TaskName + "\\Processing"));
                    }
                    catch (Exception ex)
                    {
                        LoggerHelper.ExcpLogger("NPrintingTaskCall", "GetAndSaveAttachment", ex);

                    }
                }
                foreach (var folder in taskAndReports)
                {
                    TaskName = folder;
                    try
                    {
                        if (Directory.Exists(taskStoragePath + TaskName + "\\Processing"))
                        {
                            string[] files = Directory.GetFiles(taskStoragePath + TaskName + "\\Processing");
                            foreach (string file in files)
                            {
                                fileExtension = Path.GetExtension(file);

                                if (fileExtension.ToLower() != ".html" && fileExtension.ToLower() != ".htm" && fileExtension.ToLower() != ".zip")
                                {
                                    fileName = Path.GetFileName(file);
                                    SaveTaskAndAttDetails(TaskName, fileName);
                                }

                            }
                        }
                        else
                            LoggerHelper.ExcpLogger("NPrintingTaskCall", "GetAndSaveAttachment", new Exception("Folder does not exists- " + taskStoragePath + TaskName + "\\Processing"));

                        SendEmailToUser(GetTaskAndUserDetail());
                    }
                    catch (Exception ex)
                    {
                        LoggerHelper.ExcpLogger("NPrintingTaskCall", "GetAndSaveAttachment", ex);
                    }
                }

            }
            catch (Exception ex)
            {
                LoggerHelper.ExcpLogger("NPrintingTaskCall", "GetAndSaveAttachment", ex);
            }
        }

        /// <summary> 
        /// Save attachments and task detail from outlook in database.
        /// </summary>
        static string SaveTaskAndAttDetails(string TaskName, string AttachmentName)
        {
            try
            {
                string taskQuery = DbRepository.SaveTaskDetail();
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@TaskName", TaskName));
                parameters.Add(new SqlParameter("@AttachmentName", AttachmentName));
                parameters.Add(new SqlParameter("@Result", SqlDbType.NVarChar, 2000));
                string _result = SQLHelper.ExecuteNonQueryWithOutPut(taskQuery, CommandType.StoredProcedure, parameters.ToArray());
                return _result;
            }
            catch (Exception ex)
            {
                LoggerHelper.ExcpLogger("NPrintingTaskCall", "SaveTaskAndAttDetails", ex);
                return "";
            }

        }

        /// <summary> 
        /// Get Task  And User details from database.
        /// </summary>
        static DataTable GetTaskAndUserDetail()
        {
            try
            {
                DataTable getTaskDetail = new DataTable();
                string TaskQuery = DbRepository.GetAttachmentDetails();
                getTaskDetail = SQLHelper.ExecuteAdapterWithoutParameter(TaskQuery, CommandType.StoredProcedure);
                return getTaskDetail;
            }
            catch (Exception ex)
            {
                LoggerHelper.ExcpLogger("NPrintingTaskCall", "GetTaskAndUserDetail", ex);
                return null;
            }
        }

        /// <summary> 
        /// Get Task execution details from database.
        /// </summary>
        static DataTable GetTaskExecutionDetails()
        {
            DataTable getTaskExecutionDetails = null;

            try
            {
                string taskQuery = DbRepository.GetTaskExecutionDetails();
                getTaskExecutionDetails = new DataTable();

                getTaskExecutionDetails = SQLHelper.ExecuteAdapterWithoutParameter(taskQuery, CommandType.StoredProcedure);

                return getTaskExecutionDetails;

            }
            catch (Exception ex)
            {
                LoggerHelper.ExcpLogger("NPrintingTaskCall", "GetTaskExecutionDetails", ex);
                return null;
            }
        }

        /// <summary> 
        /// Send emails to users
        /// </summary>
        static string SendEmailToUser(DataTable taskList)
        {
            try
            {
                string result = string.Empty;
                Boolean isMailSent = false;

                if (taskList != null && taskList.Rows.Count > 0)
                {
                    SmtpClient client = new SmtpClient(ConfigurationManager.AppSettings["MailingServer"]);
                    client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["MailingServerPort"]);
                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                    //  client.UseDefaultCredentials = false;
                    //  System.Net.NetworkCredential credentials = new System.Net.NetworkCredential(Decryption.Decrypt(ConfigurationManager.AppSettings["MailingServerUserID"].ToString()), Decryption.Decrypt(ConfigurationManager.AppSettings["MailingServerPassword"].ToString()));
                    client.EnableSsl = false;
                    //   client.Credentials = credentials;

                    //Get distinct task id
                    var dtUniqueTaskList = taskList.AsEnumerable()
                        .Select(row => new
                        {
                            TaskID = row.Field<string>("TaskID"),
                            TaskName = row.Field<string>("TaskName"),
                            AttachmentID = row.Field<Int32>("AttachmentID"),
                            ReportName = row.Field<string>("ReportName"),
                            AttachmentName = row.Field<string>("AttachmentName"),
                            MailSubject = row.Field<string>("MailSubject"),
                            MailCCList = row.Field<string>("MailCCList"),
                            ReportDetailsID = row.Field<int>("ReportDetailsID").ToString()

                        })
                        .Distinct();


                    MailMessage mail = null;
                    DataTable attachmentList = null;
                    foreach (var list in dtUniqueTaskList)
                    {
                        string isEmailSent = GetEmailStatus(list.TaskID);
                        if (isEmailSent != "1")
                        {
                            attachmentList = new DataTable();
                            try
                            {
                                DataTable userList = taskList.Select("TaskName ='" + list.TaskName.ToString() + "' and ReportDetailsID='" + list.ReportDetailsID + "'").CopyToDataTable();
                                mail = new MailMessage();
                                mail.From = new MailAddress(Decryption.Decrypt(ConfigurationManager.AppSettings["MailingServerUserID"].ToString().Trim()));
                                System.Net.Mail.Attachment attachment;
                                attachmentList = taskList.Select("TaskName ='" + list.TaskName.ToString() + "'").CopyToDataTable();
                                foreach (DataRow dr in attachmentList.Rows)
                                {
                                    if (dr["AttachmentName"].ToString().Split('.')[1].ToLower() != "html"
                                        || dr["AttachmentName"].ToString().Split('.')[1].ToLower() != "htm")
                                    {
                                        attachment = new System.Net.Mail.Attachment(GetAttachment(list.TaskName, dr["AttachmentName"].ToString()));
                                        mail.Attachments.Add(attachment);
                                    }
                                }
                                string mailBodyFileName = list.AttachmentName.Split('.')[0] + ".html";
                                mail.Subject = list.MailSubject;
                                mail.IsBodyHtml = true;

                                mail.Body = GetMailBody(list.TaskName, mailBodyFileName);
                                if (!string.IsNullOrWhiteSpace(list.MailCCList.ToString()))
                                {
                                    string[] ccList = list.MailCCList.Split(';');
                                    foreach (string cc in ccList)
                                    {
                                        mail.CC.Add(new MailAddress(cc));
                                    }

                                }
                                foreach (DataRow dr in userList.Rows)
                                {
                                    if (dr["Email_ID"].ToString().Trim().Contains(";"))
                                    {
                                        string[] toList = dr["Email_ID"].ToString().Trim().Split(';');
                                        foreach (string to in toList)
                                        {
                                            if (!mail.To.Contains(new MailAddress(to)))
                                                mail.To.Add(new MailAddress(to));
                                        }
                                    }
                                    else
                                    {
                                        if (!mail.To.Contains(new MailAddress(dr["Email_ID"].ToString().Trim())))
                                            mail.To.Add(new MailAddress(dr["Email_ID"].ToString().Trim()));
                                    }
                                }
                                client.Send(mail);
                                isMailSent = true;
                                result = "Success";
                            }
                            catch (Exception ex)
                            {
                                isMailSent = false;
                                LoggerHelper.ExcpLogger("NPrintingTaskCall", "SendEmailToUser", ex);

                            }
                            if (isMailSent)
                            {
                                string TaskNameForPath = list.TaskName;
                                var ReportDetailsIDList = taskList.AsEnumerable().Select(row => new { ReportDetailsID = row.Field<Int32>("ReportDetailsID"), TaskName = row.Field<string>("TaskName") }).Distinct().Where(z => z.TaskName == list.TaskName);
                                foreach (var report in ReportDetailsIDList)
                                {
                                    try
                                    {
                                        string taskQuery = DbRepository.UpdateNextRunDate();
                                        List<SqlParameter> parameters = new List<SqlParameter>();
                                        parameters.Add(new SqlParameter("@ReportDetailsID", report.ReportDetailsID));
                                        var flag = SQLHelper.ExecuteScalar(taskQuery, CommandType.StoredProcedure, parameters.ToArray());

                                    }
                                    catch (Exception ex)
                                    {
                                        LoggerHelper.ExcpLogger("WindowService Program", "UpdateNextRunDate", ex);
                                    }
                                }
                                UpdateTaskEmailFlag(Convert.ToString(list.TaskID));
                            }
                        }
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                LoggerHelper.ExcpLogger("NPrintingTaskCall", "SendEmailToUser", ex);
                return "";
            }
        }

        /// <summary> 
        /// Get attachment from local directory
        /// </summary>
        static string GetMailBody(string taskName, string attachmentName)
        {
            try
            {
                string content = string.Empty;
                string attachmentDatePath = string.Empty;
                string completeMailBodyPath = string.Empty;
                string TaskNameForPath = taskName;

                if (Directory.Exists(taskStoragePath + "\\" + TaskNameForPath + "\\Processing\\"))
                {
                    foreach (var file in Directory.GetFiles(taskStoragePath + "\\" + TaskNameForPath + "\\Processing\\"))
                    {
                        if (Path.GetExtension(file).ToLower() == ".html" || Path.GetExtension(file).ToLower() == ".htm")
                        {
                            attachmentName = Path.GetFileName(file);
                            break;
                        }
                    }

                    if (File.Exists(taskStoragePath + "\\" + TaskNameForPath + "\\Processing\\" + attachmentName))
                    {
                        completeMailBodyPath = taskStoragePath + "\\" + TaskNameForPath + "\\Processing\\" + attachmentName;

                        using (StreamReader reader = new StreamReader(completeMailBodyPath))
                        {
                            content = reader.ReadToEnd();
                        }
                    }
                }
                else
                    LoggerHelper.ExcpLogger("NPrintingTaskCall", "GetMailBody", new Exception("Folder does not exists- " + taskStoragePath + "\\" + TaskNameForPath + "\\Processing\\"));
                return content;
            }
            catch (Exception ex)
            {
                LoggerHelper.ExcpLogger("NPrintingTaskCall", "GetMailBody", ex);
                return "";
            }
        }

        /// <summary> 
        /// Get attachment from local directory
        /// </summary>
        static string GetAttachment(string taskName, string attachmentName)
        {
            try
            {
                string attachmentDatePath = string.Empty;
                string completePath = string.Empty;
                string attachmentDate = DateTime.Today.ToString("MM-dd-yyyy");
                string TaskNameForPath = taskName;
                completePath = taskStoragePath + "\\" + TaskNameForPath + "\\Processing\\" + attachmentName;
                return completePath;
            }
            catch (Exception ex)
            {
                LoggerHelper.ExcpLogger("NPrintingTaskCall", "GetAttachment", ex);
                return "";
            }
        }

        /// <summary> 
        /// Update task email flag in database
        /// </summary>
        static void UpdateTaskEmailFlag(string NPrintingTaskID)
        {
            try
            {
                string taskQuery = DbRepository.UpdateTaskEmailFlag();
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@TaskID", NPrintingTaskID));

                var result = SQLHelper.ExecuteScalar(taskQuery, CommandType.StoredProcedure, parameters.ToArray());

            }
            catch (Exception ex)
            {
                LoggerHelper.ExcpLogger("NPrintingTaskCall", "UpdateTaskEmailFlag", ex);
            }
        }
        /// <summary> 
        /// Get Email Status
        /// </summary>
        static string GetEmailStatus(string NPrintingTaskID)
        {
            string resultFlag = string.Empty;
            try
            {
                string emailTaskQuery = DbRepository.GetEmailStatus();
                List<SqlParameter> emailParameters = new List<SqlParameter>();
                emailParameters.Add(new SqlParameter("@TaskID", NPrintingTaskID));
                var emailFlag = SQLHelper.ExecuteScalar(emailTaskQuery, CommandType.StoredProcedure, emailParameters.ToArray());
                if (emailFlag != null)
                    resultFlag = emailFlag.ToString();
                return resultFlag;
            }
            catch (Exception ex)
            {
                LoggerHelper.ExcpLogger("NPrintingTaskCall", "UpdateTaskEmailFlag", ex);
                return "";
            }
        }
    }
}
