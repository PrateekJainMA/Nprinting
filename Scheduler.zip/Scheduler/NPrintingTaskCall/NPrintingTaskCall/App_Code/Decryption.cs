﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace NPrintingTaskCall.App_Code
{
    /// <summary>
    /// Function for Decrytion of the passed encrypted value
    /// </summary>
    /// <param name="cryptTxt"></param>
    /// <returns></returns>
    class Decryption
    {
        public static string Decrypt(string cryptTxt)
        {
            string decodedText = string.Empty;
            if (!string.IsNullOrWhiteSpace(cryptTxt))
            {
                try
                {
                    string[] encodedTextArray = cryptTxt.Split(new string[] { "||" }, StringSplitOptions.None);

                    foreach (string str in encodedTextArray)
                    {
                        decodedText += Convert.ToChar(Convert.ToInt32(str) + 2);//+2 as we have minus the value while encoding
                    }

                }
                catch (Exception ex)
                {
                    LoggerHelper.ExcpLogger("Decrypt", "Decryption", ex);
                }
            }
            return decodedText;
        }
    }
}
